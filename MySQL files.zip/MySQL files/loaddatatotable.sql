-- Tell MySQL which schema to use
USE loganriverodm;

-- Ensure that tables with existing primay key values of zero are created successfully
SET sql_mode='NO_AUTO_VALUE_ON_ZERO';

-- Table 1: logan river data
LOAD DATA LOCAL INFILE  'C:/Users/ryjam/Documents/MySQLPresentation/MySQL files/datavalues.csv' 
INTO TABLE datavalues
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(DataValue,LocalDateTime,UTCOffset,DateTimeUTC,SiteID,VariableID,CensorCode,QualifierID,MethodID,SourceID,QualityControlLevelID);