-- set the odm to use
use loganriverodm;

-- __________________________________________________________________________________________
-- __________________________________________________________________________________________

-- everything recored at site 2
SELECT * 
FROM DataValues
WHERE SiteID = 2 AND VariableID = 57 AND QualityControlLevelID = 1;

-- __________________________________________________________________________________________
-- __________________________________________________________________________________________

-- settig an allias as COUNT, getting the count, minim, max, avg, and not taking the nodata values.
SELECT COUNT(DataValue) AS Count, 
MIN(DataValue) AS Minimum, MAX(DataValue) AS Maximum, AVG(DataValue) AS Average 
FROM DataValues 
WHERE SiteID = 2 AND VariableID = 57 AND QualityControlLevelID = 1 AND DataValue <> -9999;

-- __________________________________________________________________________________________
-- __________________________________________________________________________________________

-- Group By example
SELECT SiteID, 
	MIN(DataValue) AS Minimum, 
    MAX(DataValue) AS Maximum, 
    AVG(DataValue) AS Average 
FROM DataValues
WHERE VariableID = 57 AND QualityControlLevelID = 1 AND DataValue <> -9999
GROUP BY SiteID;

-- __________________________________________________________________________________________
-- __________________________________________________________________________________________

-- Sorting and orering by the Date and Time example
SELECT MONTH(LocalDateTime) AS theMonth, DAY(LocalDateTime) AS theDay, AVG(DataValue) AS AvgVal
FROM DataValues  -- the odm table
WHERE SiteID = 2 AND VariableID = 57 AND QualityControlLevelID = 1 AND DataValue <> -9999
GROUP BY MONTH(LocalDateTime), DAY(LocalDateTime)
ORDER BY theMonth, theDay;

-- __________________________________________________________________________________________
-- __________________________________________________________________________________________

-- Finding relevant data for the month of August only.
SELECT MONTH(LocalDateTime) AS theMonth, DAY(LocalDateTime) AS theDay, 
AVG(DataValue) AS AvgVal
FROM DataValues  -- the odm table
WHERE SiteID = 2 AND VariableID = 57 AND QualityControlLevelID = 1 AND DataValue <> -9999 AND MONTH(LocalDateTime) = 8
GROUP BY MONTH(LocalDateTime), DAY(LocalDateTime)
ORDER BY theMonth, theDay;
-- __________________________________________________________________________________________
-- __________________________________________________________________________________________

-- Arithmetic Functions. can change the + to - an * and /
-- Note: variable ID = temperature data, not elevation, but still illustrates this example well.
SELECT LocalDateTime, DataValue + 4380 AS Elevation
FROM DataValues 
WHERE SiteID = 2 AND VariableID = 57 AND QualityControlLevelID = 1
ORDER BY LocalDateTime ASC;

-- __________________________________________________________________________________________
-- __________________________________________________________________________________________

-- Sub Queries.  good way to look for things not matched up. our data is qualtiy contorlled for somethings.
SELECT VariableID, VariableName 
FROM Variables 
WHERE VariableID NOT IN (SELECT DISTINCT VariableID FROM DataValues)
ORDER BY VariableID;

-- or
-- data value must be greater than the avg value
SELECT * 
FROM DataValues
WHERE SiteID = 2 AND VariableID = 57 AND QualityControlLevelID = 1 AND DataValue > 	(SELECT AVG(DataValue) FROM DataValues 	WHERE SiteID = 2 AND VariableID = 57 AND QualityControlLevelID = 1 AND DataValue <> -9999);
